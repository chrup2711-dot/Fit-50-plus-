package cz.fit50plus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Fit50App() }
    }
}

@Composable
fun Fit50App() {
    var dark by remember { mutableStateOf(false) }
    var ai by remember { mutableStateOf(false) }
    var activity by remember { mutableStateOf("Běh") }
    var health by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
                Text("FIT 50+", style = MaterialTheme.typography.headlineLarge)
                Text("Pohyb, zdraví a kondice po padesátce", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(20.dp))
                Text("Vyber aktivitu", style = MaterialTheme.typography.titleLarge)
                listOf("Běh", "Chůze", "Kolo", "Posilování").forEach {
                    Row { RadioButton(selected = activity == it, onClick = { activity = it }); Text(it, Modifier.padding(top = 12.dp)) }
                }
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                Text("Zdravotní stav", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(value = health, onValueChange = { health = it }, label = { Text("Zdravotní omezení nebo poznámky") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Spacer(Modifier.height(12.dp))
                Text("Tréninkový deník", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Poznámka k tréninku") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Spacer(Modifier.height(12.dp))
                Row { Text("Tmavý vzhled", Modifier.weight(1f).padding(top = 12.dp)); Switch(dark, { dark = it }) }
                Row { Text("Asistent AI", Modifier.weight(1f).padding(top = 12.dp)); Switch(ai, { ai = it }) }
                Text(if (ai) "AI je zapnutá – připojení služby bude doplněno." else "AI je vypnutá.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(18.dp))
                Text("Další části projektu", style = MaterialTheme.typography.titleLarge)
                Text("• Ukládání a sdílení tras\n• Závody v okolí\n• Import tréninků z hodinek Polar\n• Komunita a sdílení sportovních úspěchů")
                Text("Toto je první testovací verze rozhraní. Záznamy se zatím trvale neukládají.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 18.dp))
            }
        }
    }
}
